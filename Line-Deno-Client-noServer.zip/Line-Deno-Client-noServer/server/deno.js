import write from "./write_deno.js";
import read from "./read_deno.js";
import { TBinaryProtocol, TCompactProtocol } from "npm:thrift@0.20.0";
import { Buffer } from "node:buffer";
TBinaryProtocol.genHeader = (name) => {
    return Buffer.from([
        0x80,
        1,
        0,
        1,
        0,
        0,
        0,
        name.length,
        ...Buffer.from(name),
        0,
        0,
        0,
        0,
    ]);
};
TCompactProtocol.genHeader = (name) => {
    return Buffer.from([
        0x82,
        0x21,
        0,
        name.length,
        ...Buffer.from(name),
    ]);
};

const Protocols = {
    4: TCompactProtocol,
    3: TBinaryProtocol,
    0: Buffer,
};

export class lineClient {
    constructor(authToken, device) {
        let appVer, sysName, sysVer;
        sysVer = "12.1.4";
        switch (device) {
            case "DESKTOPWIN":
                appVer = "7.16.1.3000";
                sysName = "WINDOWS";
                sysVer = "10.0.0-NT-x64";
                break;
            case "DESKTOPMAC":
                appVer = "7.16.1.3000";
                sysName = "MAC";
                break;
            case "CHROMEOS":
                appVer = "3.0.3";
                sysName = "Chrome_OS";
                sysVer = "1";
                break;
            case "ANDROID":
                appVer = "13.4.1";
                sysName = "Android OS";
                break;
            case "IOS":
                appVer = "13.3.0";
                sysName = "iOS";
                break;
            case "IOSIPAD":
                appVer = "13.3.0";
                sysName = "iOS";
                break;
            case "WATCHOS":
                appVer = "13.3.0";
                sysName = "Watch OS";
                break;
            case "WEAROS":
                appVer = "13.4.1";
                sysName = "Wear OS";
                break;
            default:
                throw new Error("deviceName is wrong");
                break;
        }
        this.type = device + "\t" + appVer + "\t" + sysName + "\t" + sysVer;
        this.ua = "Line/" + appVer;
        this.authToken = authToken;
    }
}
export async function request(path, value, name, cl, ptype, add_headers = {}) {
    const Protocol = Protocols[ptype];
    let headers = {
        "Host": "gw.line.naver.jp",
        "accept": "application/x-thrift",
        "user-agent": cl.ua,
        "x-line-application": cl.type,
        "x-line-access": cl.authToken,
        "content-type": "application/x-thrift",
        "x-lal": "ja_JP",
        //'x-le': '18', 'x-lap': '5',
        "x-lpv": "1",
        "x-lhm": "POST",
        //"x-lcs":'0005svgBAiJMiGMJdzBkKqR/78GAZEMOQ6E0p3FJkMBZA/NXe10zfYnVQDufzNaRMEW1nvYJYsLWZaWb4ww7EsebLNXGbuhmyAT2V4Fr3tA23xzvvbOaLjCahQK/4qrha2gC54XuPRbtSFNzALjs3rAyfWyczSnlenV/KFv06iqMmt1v+l3KBQdBkN9uLqGRTXzII0Y/rXtkw1wTYvMZZB7b6KunfzHf9AbFOMCqyveInGhYAetFN9Ly9x3kf2uC2czTSlynvelkYn4qn2VeGmAWOLqZrbQelyh/rRIFPttCILbOrWNEwv71Y7Pa1C0MTGFGlWWQQKlBHj0lcK+kJL13Ww==',
        "accept-encoding": "gzip",
    };
    headers = { ...headers, ...add_headers };
    let res;
    if (Protocol !== Buffer) {
        try {
            res = {};
            const Trequest = write(value, name, Protocol);
            await Deno.writeFile("./tmpReq.bin", Trequest); /////////////////////////
            const fet = await fetch("https://gw.line.naver.jp" + path, {
                method: "POST",
                headers: headers,
                body: Trequest,
            });
            res = await fet.arrayBuffer();
            res = new Uint8Array(res);
            Deno.writeFile("./tmpRes.bin", res); /////////////////////////////
            res = read(res, Protocol);
        } catch (error) {
            console.log(error, "/", res);
        }
        return res;
    } else {
        try {
            res = {};
            const Trequest = value;
            await Deno.writeFile("./tmpReq.bin", Trequest); /////////////////////////
            const fet = await fetch("https://gw.line.naver.jp" + path, {
                method: "POST",
                headers: headers,
                body: Trequest,
            });
            res = await fet.arrayBuffer();
            res = new Uint8Array(res);
            Deno.writeFile("./tmpRes.bin", res); /////////////////////////////
        } catch (error) {
            console.log(error, "/", res);
        }
        return res;
    }
}

export function init(authToken, device) {
    globalThis.LINE = new lineClient(authToken, device);
    globalThis.LINE.request = (path, value, name, ptype, add_headers = {}) => {
        return request(path, value, name, globalThis.LINE, ptype, add_headers);
    };
    return globalThis.LINE;
}
